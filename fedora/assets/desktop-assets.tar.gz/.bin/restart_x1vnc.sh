#!/bin/bash

# Pequeno delay para garantir que a sess�o gr�fica j� subiu completamente
sleep 1

# Reinicia o servi�o x11vnc do usu�rio atual
systemctl --user restart x11vnc.service
